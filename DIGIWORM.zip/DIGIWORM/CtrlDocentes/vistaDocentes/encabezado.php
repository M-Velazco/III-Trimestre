<table width="70%" border="0" align="center">
  <tr>
    <td align="center"><H1>*+* DOCENTES *+*</H1></td>
  </tr>
</table>