<?php

require ( "../ctrlDocentes/modeloDocentes/Docentes.php");
require "../ctrlDocentes/modeloDocentes/conexion.php";
extract ($_REQUEST);

$objConexion = Conectarse();

$sql="select * from docente where iddocente = '$_REQUEST[IDdocente]'";
$resultadodocente = $objConexion->query($sql);

$docente = $resultadodocente->fetch_object();


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Formulario Actualizar Medico</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="validaractualizarDocente.php">
  <table width="42%" border="0" align="center">
    <tr>
      <td colspan="2" align="center" bgcolor="#FFCC00">ACTUALIZAR DOCENTE</td>
    </tr>
    <tr>
      <td width="37%" align="right" bgcolor="#EAEAEA">Numero de Identificacion del docente</td>
      <td width="63%"><label for="IDdocente"></label>
      
      <input name="fIDdocente" type="int" id="IDdocente" value="<?php echo $docente->iddocente?>" readonly size="40" />
      
      </td>
    </tr>
    <tr>
      <td align="right" bgcolor="#EAEAEA">Nombres y apellidos:</td>
      <td><label for="Nombre_apellidos"></label>
      <input name="fNombre_apellidos" type="text" id="Nombre_apellidos" value="<?php echo $docente->Nombre_apellido?>" size="40"  /></td>
    </tr>
    <tr>
      <td align="right" bgcolor="#EAEAEA">Correo:</td>
      <td><label for="Correo"></label>
      <input name="fCorreo" type="email" id="Correo" value="<?php echo $docente->Correo?>" size="40" /></td>
    </tr>
    <tr>
      <td align="right" bgcolor="#EAEAEA">Contraseña:</td>
      <td><label for="Contraseña"></label>
      <input name="fContraseña" type="password" id="Contraseña" value="<?php echo $docente->Contraseña?>" size="40" /></td>
    </tr>
    <tr>
      <td align="right" bgcolor="#EAEAEA">Curso:</td>
      <td><label for="Curso_pr"></label>
      <input name="fCurso_pr" type="int" id="Curso_pr" value="<?php echo $docente->Curso_pr?>" size="40" /></td>
    </tr>
    <tr>
      <td align="right" bgcolor="#EAEAEA">Materia:</td>
      <td><label for="Materia"></label>
      <input name="fMateria" type="int" id="Materia" value="<?php echo $docente->Materia?>" size="40" /></td>
    </tr>
    
   
   
    <tr>
      <td colspan="2" align="center" bgcolor="#FFCC00"><input type="submit" name="button" id="button" value="Enviar" /></td>
    </tr>
  </table>
  
  
  
  
</form>
</body>
</html>